
const navbar = (
    <nav>
        <h1>The test site</h1>
        <ul>
        <li>about</li>
        <li>contact</li>
        <li>menu</li>
        </ul>
    </nav>
)
ReactDOM.render (navbar, document.getElementById("root"))

